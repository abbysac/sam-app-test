# eft-serverless-admin-lambda
EFT Serverless Admin Lambda Code repository
